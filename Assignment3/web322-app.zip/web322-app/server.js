
// /*********************************************************************************
// *  WEB322 – Assignment 03
// *  I declare that this assignment is my own work in accordance with Seneca  Academic Policy.  No part *  of this assignment has been copied manually or electronically from any other source 
// *  (including 3rd party web sites) or distributed to other students.
// * 
// *  Name: _Hwisun Bae_____ Student ID: __128835170__ Date: Oct 30, 2018
// *
// *  Online (Heroku) Link: _https://hwisun-web322-assign3.herokuapp.com/
// *
// ********************************************************************************/ 

var express = require("express");
// var http = require("http");

var app = express();
var HTTP_PORT = process.env.PORT || 8080;
var fs = require("fs");
var path = require("path");
// var dataD = require("./data/departments");
// var dataE = require("./data/employees");
var dataService = require("./data-service");
var multer = require('multer');

const storage = multer.diskStorage({
    destination: "./public/images/uploaded",
    filename: function (req, file, cb) {
        // The disk storage engine gives you full control on storing files to disk.
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

var bodyParser = require('body-parser');

app.use(bodyParser.urlencoded({ extended: true }));
//add CSS
app.use(express.static(path.join(__dirname, '/public'))); 

var upload = multer({storage : storage});

// call this function after the http server starts listening for requests
function onHttpStart() {
  console.log("Express http server listening on: " + HTTP_PORT);
  return new Promise (function (req, res){
      dataService.initialize().then(function(data){
          console.log(data);
      }).catch(function(err){
          console.log(err);
      });
  });
};

// setup a 'route' to listen on the default url path
// The route "/" must return the home.html file from the views folder
app.get("/", (req, res) => {
    res.sendfile('views/home.html');
});

// The route "/about" must return the about.html file from the views folder
app.get("/about", (req, res) => {
    res.sendfile('views/about.html');
});
 
app.get("/employees", (req, res) => {
    if (req.query.status){
        dataService.getEmployeesByStatus(req.query.status).then((data) => {
            res.json(data);
        }).catch((err) => {
            res.json( {message : 'no results'});
        });
    } else if (req.query.department) {
        dataService.getEmployeesByDepartment(req.query.department).then((data) => {
            res.json(data);
        }).catch((err) => {
            res.json( {message : 'no results'});
        });
    } else if (req.query.manager) {
        dataService.getEmployeesByManager(req.query.manager).then((data) => {
            res.json(data);
        }).catch((err) => {
            res.json( {message : 'no results'});
        });
    } else {
        dataService.getAllEmployees().then((data) => {
            res.json(data);
        }).catch ((err) => {
            res.json( {message : 'no results'});
        });
    }
});

app.get('/employees/add', (req, res)=> {
    res.sendFile(path.join(__dirname, "/views/addEmployee.html"));
});

app.post('/employees/add', (req, res) => {
    dataService.addEmployee(req.body).then(() => {
        res.redirect('/employees');
    });
});

app.get('/employee/:num', (req,res) => {
    dataService.getEmployeeByNum(req.params.num).then((data) => {
        res.json(data);
    }).catch((err) => {
        res.json({message : err});
    });
});

app.get("/managers", (req, res) => {
    dataService.getManagers().then((data)=>{
        res.json(data);
    }).catch((err) => {
        res.json({message: err});
    });
    // res.writeHead(200, {"Content-Type" : "text/json"});
    // isManager(res);  
});
// employees whose isManager property is set to true.
function isManager(res){
    var manager = dataE.filter(function (person) {
        return person.isManager === true;
    });
    res.end(JSON.stringify(manager));
}

app.get("/departments", (req, res) => {
    dataService.getDepartments().then((data)=>{
        res.json(data);
    }).catch((err) => {
        res.json({message: err});
    });
    // res.writeHead(200, {"Content-Type" : "text/json"});
    // res.end((JSON.stringify(dataD)));
});

/* 
images 
-------------*/

app.get('/images', (req, res) => {
    fs.readdir('./public/images/uploaded', (err, items) => {
        res.json({images : items});
    });
});

app.post('/images/add', upload.single('imageFile'), (req,res) => {
    res.redirect('/images');
});

app.get('/images/add', (req,res)=> {
    res.sendFile(path.join(__dirname, "/views/addImage.html"));
});

app.get ('*', (req, res) => {
    res.send("Page Not found", 404);
});

// setup http server to listen on HTTP_PORT
app.listen(HTTP_PORT, onHttpStart);

