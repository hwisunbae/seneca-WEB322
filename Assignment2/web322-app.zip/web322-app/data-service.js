var fs = require("fs");

//globally declared arrays
var employees = []; 
var departments = []; 

module.exports.initialize = () => {
    return new Promise((resolve,reject) => {
        //use then and catch instead
        try {
            fs.readFile('./data/employees.json', 'utf8', (err, data) => {
                if(err) throw err;
                employees = JSON.parse(data);
            });
            fs.readFile('./data/departments.json', 'utf8', (err, data) => {
                if(err) throw err;
                departments = JSON.parse(data);
            });
        } catch(err){
            reject("Unable to read file");
        }
        resolve("operation was a success");
    });
};

module.exports.getAllEmployees = () => {
    var allEmployees=[];
    return new Promise((resolve, reject) => {
        for (var i = 0; i < employees.length; i++) {
            allEmployees.push(employees[i]);
        }
        if (allEmployees.length == 0){
            reject("no results returned");
        }
        resolve(allEmployees);
    });
};

module.exports.getManagers = () => {
    var employee=[];
    return new Promise((resolve, reject) => {
        for (var i = 0; i < employees.length; i++) {
            if (employees[i].isManager === true) {
                employee.push(employees[i]);
            }
        }
        if (employee.length === 0){
            reject("no results returned");
        }
        resolve(employee);
    });
};

module.exports.getDepartments = () => {
    var department=[];
    return new Promise((resolve, reject) => {
        for (var i = 0; i < departments.length; i++) {
            department.push(departments[i]);
        }
        if (department.length === 0){
            reject("no results returned");
        }
        resolve(department);
    });
};
