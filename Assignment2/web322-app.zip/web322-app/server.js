/*********************************************************************************
*  WEB322 – Assignment 02
*  I declare that this assignment is my own work in accordance with Seneca  Academic Policy.  No part *  of this assignment has been copied manually or electronically from any other source 
*  (including 3rd party web sites) or distributed to other students.
* 
*  Name: _Hwisun Bae_____ Student ID: __128835170__ Date: _Sep 25, 2018
*
*  Online (Heroku) Link: _https://hwisun-web322-assign2.herokuapp.com/
*
********************************************************************************/ 

var express = require("express");
// var http = require("http");

var app = express();
var HTTP_PORT = process.env.PORT || 8080;
var fs = require("fs");
var path = require("path");
var dataD = require("./data/departments");
var dataE = require("./data/employees");
var dataService = require("./data-service");

// call this function after the http server starts listening for requests
function onHttpStart() {
  console.log("Express http server listening on: " + HTTP_PORT);
  return new Promise (function (req, res){
      dataService.initialize().then(function(data){
          console.log(data);
      }).catch(function(err){
          console.log(err);
      });
  });
};

//add CSS
app.use(express.static(path.join(__dirname, '/public'))); 

// http.createServer(function (req,res){
//     res.writeHead(200, {"Content-Type" : "text/json"});
//     res.end((JSON.stringify(dataD)));

//     // if( req.url.match(/.css$/)){
//     // var cssPath = path.join(__dirname, 'public', 'css', req.url);
//     // var fileStream = fs.createReadStream(cssPath, "UTF-8");

//     // res.writeHead(200, {"Content-Type": "text/css"});
//     // fileStream.pipe(res);
//     // } 
// }).listen(8080);
// console.log("Server listening on port 8080");


// setup a 'route' to listen on the default url path
// The route "/" must return the home.html file from the views folder
app.get("/", (req, res) => {
    res.sendfile('views/home.html');
});

// The route "/about" must return the about.html file from the views folder
app.get("/about", (req, res) => {
    res.sendfile('views/about.html');
});
 
app.get("/employees", (req, res) => {
    dataService.getAllEmployees().then((data)=>{
        res.json(data);
    }).catch((err) => {
        res.json({message: err});
    });
    // res.writeHead(200, {"Content-Type" : "text/json"});
    // res.end((JSON.stringify(dataE)));
});
app.get("/managers", (req, res) => {
    dataService.getManagers().then((data)=>{
        res.json(data);
    }).catch((err) => {
        res.json({message: err});
    });
    // res.writeHead(200, {"Content-Type" : "text/json"});
    // isManager(res);  
});
// employees whose isManager property is set to true.
function isManager(res){
    var manager = dataE.filter(function (person) {
        return person.isManager === true;
    });
    res.end(JSON.stringify(manager));
}

app.get("/departments", (req, res) => {
    dataService.getDepartments().then((data)=>{
        res.json(data);
    }).catch((err) => {
        res.json({message: err});
    });
    // res.writeHead(200, {"Content-Type" : "text/json"});
    // res.end((JSON.stringify(dataD)));
});

app.get ('*', (req, res) => {
    res.send("Page Not found", 404);
});


// setup http server to listen on HTTP_PORT
app.listen(HTTP_PORT, onHttpStart);

